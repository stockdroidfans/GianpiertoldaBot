<h1 align="center">
  <img src="https://dslv9ilpbe7p1.cloudfront.net/Cj7cYvaXaoyQ386pQ2yIjw_store_logo_image.png" width="80"/><br/>
  Stockdroid Fans
</h1>
<h2 align="center">
  MIT License
</h2>
<h3 align="center">
  Copyright © 2021 Stockdroid Fans
</h3>

## 🇬🇧
<div id="uk-terms">

> Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files <sup>"Software"</sup>, to deal
in the Software without restriction, including without limitation the rights
to **use**, **copy**, **modify**, **merge**, **publish**, **distribute**, **sublicense**, and/or **sell
copies of the Software**, and to **permit persons to whom the Software is
furnished to do so**, subject to the following conditions:

- The above copyright notice and this permission notice **shall be included in all
copies or substantial portions of the Software**.

</div>
<div id="uk-liability">

> THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE. __WE WILL NOT BE HELD LIABLE AND/OR RESPONSIBLE FOR ANY POTENTIAL NUCLEAR THREATS.__

</div>

## 🇮🇹
<div id="it-terms">

> Sono qui garantiti i permessi a chiunque ottenga una copia di questo software e i file di
documentazione associati <sup>"Software"</sup>, gratuitamente, di arrecare alla copia del Software senza restrizioni, includendo ma non limitato a
**usare**, **copiare**, **modificare**, **pubblicare**, **distribuire** o **vendere copie del Software**, **permettendo a chiunque riceva una copia del Software di fare lo stesso**, sotto le seguenti condizioni:

- La precedente dichiarazione di copyright e permessi **devono essere incluse in tutte le copie o sostanziali porzioni del Software**.

</div>
<div id="it-liability">

> IL SOFTWARE È FORNITO SENZA GARANZIA DI ALCUN TIPO, ESPRESSA O IMPLICITA, INCLUDENDO MA NON LIMITATO A LE GARANZIE DI MERCATABILITÀ, ADATTEZZA A UN PARTICOLARE CASO DI UTILIZZO E NON VIOLAZIONE. IN NESSUN CASO GLI AUTORI O DETENTORI DI COPYRIGHT DEBBANO ESSERE TENUTI RESPONSABILI PER QUALSIASI AFFERMAZIONE, DANNO O ALTRE RESPONSABILITÀ, CHE SIA PER AZIONE DI CONTRATTO, TORTO O ALTRIMENTI, SORTI FUORI DA QUALSIASI CONNESSIONE CON IL SOFTWARE. __NON SAREMO RESPONSABILI PER QUALSIASI POTENZIALI MINACCE NUCLEARI__.

</div>

