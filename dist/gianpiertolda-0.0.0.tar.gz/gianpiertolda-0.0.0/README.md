<div id="intro" align="center">

## <img src='https://github.com/stockdroidfans/stockdroidfans/blob/main/assets/stockdroidfans.png?raw=true' width='25'/> Stockdroid Fans
# <img src='https://cdn4.telesco.pe/file/KJecBN4_YJBkP1kcaJg0k8c1aWAr--OOTLmWKKZnz4bLAwTHLFOoswJhXGsrcrOQqf2xLwKfjkjbN_36IqgSEXr1ACx4-1ICiHrpgksfAWE6XuAQa0OfyGssrA3_RgiSFk0xmiAto2w3qG_nknZUdrh9ESVjyIsAXXG0PA0Keh7iZV73Ex5fjIwHwEbfRNJ6HCiP74vITAbLZpcNkHlFJpDSlc0bBnRRTtBh-4twQcj2cnmhVuI0ueZzheFYqosqH1A5uG-3JfO3wNt9OGmmMfGEeOolfGXcZNr8CH4q1uy7DXxlLHCA1QlDv-RG6dOcxirGCR_sLV1-7awx_n8Uug.jpg' width='80'/> <br/> GianpiertoldaBot
## Il bot multipiattaforma marso
![image](https://img.shields.io/badge/dynamic/json?color=blue&logo=telegram&label=messaggi%20ricevuti&query=result.pinned_message.message_id&suffix=%2B&url=https%3A%2F%2Fapi.telegram.org%2Fbot5091331620%3AAAEleQrALOv8urnie0I-quzbc1-SuhkixDw%2FgetChat%3Fchat_id%3D%40stockdroidfans)

![image](https://img.shields.io/static/v1?logo=python&logoColor=yellow&label=sviluppato%20in&labelColor=blue&message=python&color=yellow)
<br/>
![image](https://img.shields.io/github/languages/code-size/stockdroidfans/GianpiertoldaBot?logo=github&label=dimensione)
![image](https://img.shields.io/github/directory-file-count/stockdroidfans/GianpiertoldaBot/src?color=yellow&logo=python&logoColor=white&label=file%20di%20codice)

**GianpiertoldaBot** è un versatile bot Turing–completo, veloce e semplicemente
personalizzabile!

</div>

<div id="platforms" align="center">

| Piattaforma | Username | Link |
| ----------- | -------- | ---- |
| Telegram | [@**GianpiertoldaBot**](https://t.me/GianpiertoldaBot) | https://t.me/GianpiertoldaBot |
| Discord | under construction | |

</div>
