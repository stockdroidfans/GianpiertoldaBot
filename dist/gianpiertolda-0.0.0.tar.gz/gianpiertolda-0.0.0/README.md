boh scriviamo una cazzata a caso che magari funziona

> With the hand of my best friend, if you dont work i <inserire minaccia qui> ho io qualcosa:

